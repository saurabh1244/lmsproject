from django.contrib import admin

from .models import Contact , PersonDetails


class ContactAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'sub','comment']

class PersonDetailAdmin(admin.ModelAdmin):
    list_display = ['name', 'age', 'total']




admin.site.register(PersonDetails, PersonDetailAdmin)

admin.site.register(Contact, ContactAdmin)
