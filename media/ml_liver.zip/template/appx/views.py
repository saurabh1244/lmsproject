from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

from django.shortcuts import render , HttpResponse ,redirect
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.db.models import Q
from django.contrib.auth import authenticate , login , logout

from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .models import Contact , PersonDetails



@login_required(login_url='/login/')
def test(request):
    if request.method == 'POST':
        name = request.POST['name']
        age = request.POST['age']

        sodium_blood = int(request.POST.get('sodium_blood' , 0) )

        liver_enzyme = int( request.POST.get('liver_enzyme' , 0) )  

        bilirubin = int(request.POST.get('bilirubin' , 0))

        o2 = int(request.POST.get('o2' , 0))

        sugar = int(request.POST.get('sugar' , 0))

        bp = int(request.POST.get('bp' , 0))

        nausea = 2 if request.POST.get('nausea') == 'on' else 0
       
        Feeling_weak = 2 if request.POST.get('Feeling_weak') == 'on' else 0
       
        Feeling_ill = 2 if request.POST.get('Feeling_ill') == 'on' else 0
   
        upper_pain = 3 if request.POST.get('upper_pain') == 'on' else 0

        spider = 2 if request.POST.get('spider') == 'on' else 0

        jaundice = 2 if request.POST.get('jaundice') == 'on' else 0

        digest = 3 if request.POST.get('digest') == 'on' else 0

        w_loss = 2 if request.POST.get('w_loss') == 'on' else 0

        m_loss = 2 if request.POST.get('m_loss') == 'on' else 0

        swelling = 3 if request.POST.get('swelling') == 'on' else 0

        itching = 2 if request.POST.get('itching') == 'on' else 0

        vomit_blood = 8 if request.POST.get('vomit_blood') == 'on' else 0

        short_breath = 7 if request.POST.get('short_breath') == 'on' else 0

        
        total = sodium_blood + liver_enzyme + bilirubin + o2 + sugar + bp + \
                nausea + Feeling_ill + Feeling_weak + spider + upper_pain + jaundice + \
                digest + w_loss + m_loss + swelling + itching + vomit_blood + \
                short_breath
        
      
        print(total)


        obj = PersonDetails.objects.create(user=request.user, name=name, age=age
                                            ,sodium_blood=sodium_blood ,liver_enzyme=liver_enzyme,
                                            bilirubin=bilirubin,o2=o2, sugar=sugar,bp=bp,nausea=nausea , 
                                            Feeling_weak=Feeling_weak ,Feeling_ill=Feeling_ill,upper_pain=upper_pain, 
                                            spider=spider, jaundice=jaundice , digest=digest ,w_loss=w_loss , m_loss=m_loss ,
                                              swelling=swelling,itching=itching , vomit_blood=vomit_blood, short_breath=short_breath,total=total)
        obj.save()

        messages.success(request, f"{name} and age {age} you have  {total}% chanse of liver disease  ")


        return render(request, 'test.html', {'data': total})

    return render(request ,'test.html')





def register_page(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        username = request.POST.get('uname')
        email = request.POST.get('email')
        passx = request.POST.get('passx')

        print(fname, lname, email,passx ,username )



        obj = User.objects.create(username = username , first_name=fname,last_name=lname,email=email )
        obj.set_password(passx)
        obj.save()

        print(fname, lname, email,passx ,username )

    return render(request, 'register.html')


def login_page(request):
    if request.method == 'POST':
        username = request.POST.get('uname')
        passx = request.POST['passx']

        if User.objects.filter(username=username).exists():
            user_obj = authenticate(username=username,password=passx)
            login(request,user_obj)
            print('login sucess using ...')
            print(username,passx)
            return redirect('/')

        else:
            return HttpResponse('any error occuredin if statement')

    return render(request , 'login.html')


def logout_page(request):
    logout(request)
    return redirect('/')




def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        sub = request.POST.get('sub')
        comment = request.POST.get('comment')


        print(name,email,sub,comment)

        obj = Contact.objects.create(name=name,email=email,sub=sub,comment=comment)
        obj.save()



        return render(request, 'contact.html')
    

    return render(request, 'contact.html')


def home(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')


def blog(request):
    return render(request, 'blog.html')




def departments(request):
    return render(request, 'departments.html')

def doctor(request):
    return render(request, 'doctor.html')