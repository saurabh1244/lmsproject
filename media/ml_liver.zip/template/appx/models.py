from django.db import models

from django.contrib.auth.models import User



class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    sub = models.CharField(max_length=100)
    comment = models.CharField(max_length=400)


class PersonDetails(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    age = models.CharField(max_length=100)

    sodium_blood = models.IntegerField()
    liver_enzyme = models.IntegerField()
    bilirubin = models.IntegerField()
    o2 = models.IntegerField()
    sugar = models.IntegerField()
    bp = models.IntegerField()
    nausea = models.IntegerField()
    Feeling_weak = models.IntegerField()
    Feeling_ill = models.IntegerField()
    upper_pain = models.IntegerField()
    spider = models.IntegerField()
    jaundice = models.IntegerField()
    digest = models.IntegerField()
    w_loss = models.IntegerField()
    m_loss = models.IntegerField()
    swelling = models.IntegerField()
    itching = models.IntegerField()
    vomit_blood = models.IntegerField()
    short_breath =  models.IntegerField()
    total = models.IntegerField()
    

    


